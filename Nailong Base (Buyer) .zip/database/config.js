module.exports = {
  tokens: "8756337743:AAG3uUUeiI1ksOxBV-qzQWyLEFM16YoG4Hg",  // Ubah Jadi Token Bot Mu !!!
  owner: "8362454903", // Ubah Jadi Id Mu !!!
  port: "2250", // Ubah Jadi Port Panel Mu !!!
  ipvps: "114.79.3.231" // Ubah Jadi Ip Vps Mu !!!
};